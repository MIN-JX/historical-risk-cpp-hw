var searchData=
[
  ['publishing_2emd_0',['publishing.md',['../publishing_8md.html',1,'']]]
];
