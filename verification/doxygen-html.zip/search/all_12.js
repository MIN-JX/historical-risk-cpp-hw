var searchData=
[
  ['why_20the_20estimators_20are_20comparable_0',['Why the estimators are comparable',['../md_docs_2algorithms.html#autotoc_md8',1,'']]],
  ['worked_20examples_1',['Worked examples',['../md_docs_2model.html#autotoc_md15',1,'']]],
  ['worst_5floss_2',['worst_loss',['../structrisk_1_1_metrics.html#a5593319acd053e491da3328c67d12768',1,'risk::Metrics']]]
];
