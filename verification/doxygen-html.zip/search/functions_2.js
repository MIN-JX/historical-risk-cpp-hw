var searchData=
[
  ['validate_0',['validate',['../namespacerisk.html#acd68e2abf7ec145257a5ae138773d0fd',1,'risk']]]
];
