var searchData=
[
  ['max_5fobservations_0',['max_observations',['../namespacerisk.html#ae4d8ff09eab8982c715a34c789fec564',1,'risk']]],
  ['mean_5floss_1',['mean_loss',['../structrisk_1_1_metrics.html#a348aa3716546b52aea65efeadc30c6a4',1,'risk::Metrics']]]
];
