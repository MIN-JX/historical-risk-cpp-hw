var searchData=
[
  ['partition_20selection_0',['Partition selection',['../md_docs_2algorithms.html#autotoc_md7',1,'']]],
  ['partition_20selection_1',['Sorting and partition selection',['../md_docs_2algorithms.html',1,'']]],
  ['prepare_20the_20repository_2',['Prepare the repository',['../md_docs_2publishing.html#autotoc_md18',1,'']]],
  ['project_3',['Run the project',['../index.html#autotoc_md1',1,'']]],
  ['project_20owner_20s_20account_4',['Publishing in the project owner&apos;s account',['../md_docs_2publishing.html',1,'']]],
  ['publishing_20in_20the_20project_20owner_20s_20account_5',['Publishing in the project owner&apos;s account',['../md_docs_2publishing.html',1,'']]]
];
