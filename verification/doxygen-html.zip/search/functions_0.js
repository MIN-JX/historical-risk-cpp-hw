var searchData=
[
  ['estimate_5fpartition_0',['estimate_partition',['../namespacerisk.html#a4d47e4b9ff0dc354a9ad2748aa7bfb1e',1,'risk']]],
  ['estimate_5fsort_1',['estimate_sort',['../namespacerisk.html#ade0a5e6b0f5431075f8e04387e04b8ef',1,'risk']]]
];
