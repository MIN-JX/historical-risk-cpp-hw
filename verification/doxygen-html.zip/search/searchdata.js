var indexSectionsWithContent =
{
  0: "abcdefhilmnopqrstvw",
  1: "m",
  2: "r",
  3: "abmpr",
  4: "emv",
  5: "emvw",
  6: "abcdefhilnopqrstvw"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Pages"
};

