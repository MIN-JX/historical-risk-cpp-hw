var searchData=
[
  ['worst_5floss_0',['worst_loss',['../structrisk_1_1_metrics.html#a5593319acd053e491da3328c67d12768',1,'risk::Metrics']]]
];
