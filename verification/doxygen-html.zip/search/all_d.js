var searchData=
[
  ['questions_20for_20code_20review_0',['Questions for code review',['../md_docs_2algorithms.html#autotoc_md9',1,'']]]
];
