var searchData=
[
  ['value_5fat_5frisk_0',['value_at_risk',['../structrisk_1_1_metrics.html#a3c9feae10b5c9773a06813848cba5aa3',1,'risk::Metrics']]]
];
