var searchData=
[
  ['for_20code_20review_0',['Questions for code review',['../md_docs_2algorithms.html#autotoc_md9',1,'']]],
  ['full_20sorting_1',['Full sorting',['../md_docs_2algorithms.html#autotoc_md6',1,'']]]
];
