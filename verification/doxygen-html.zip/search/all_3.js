var searchData=
[
  ['definitions_0',['Empirical risk definitions',['../md_docs_2model.html',1,'']]]
];
