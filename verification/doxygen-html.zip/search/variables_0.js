var searchData=
[
  ['expected_5fshortfall_0',['expected_shortfall',['../structrisk_1_1_metrics.html#a89932fe1022bfedd8b81c922460982be',1,'risk::Metrics']]]
];
